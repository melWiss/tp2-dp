package com.design.tp2.factory.scooter;

public class ScooterElectricite extends Scooter {
    @Override
    public void featuresDisplay() {
        System.out.println("merci");
    }
}
