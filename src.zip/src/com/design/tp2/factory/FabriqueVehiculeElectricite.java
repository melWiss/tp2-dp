package com.design.tp2.factory;

import com.design.tp2.factory.automobile.Automobile;
import com.design.tp2.factory.scooter.Scooter;

public class FabriqueVehiculeElectricite implements FabriqueVehicule{
    @Override
    public Automobile creeAutomobile() {
        return null;
    }

    @Override
    public Scooter creeScooter() {
        return null;
    }
}
