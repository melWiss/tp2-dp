package com.design.tp2.factory.automobile;

public class AutomobileElectricite extends Automobile{
    @Override
    public void featuresDisplay() {
        System.out.println("merci");
    }
}
