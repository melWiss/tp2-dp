package com.design.tp2.factory.automobile;

public class AutomobileEssence extends Automobile{
    @Override
    public void featuresDisplay() {
        System.out.println("merci");
    }
}
