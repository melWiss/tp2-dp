package com.design.tp2.factory;

public class Catalogue {
}
